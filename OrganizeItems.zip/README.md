# OrganizeItems
A mod that organizes all the items on the ship so you don't have to.

## Installation
- Install [BepInEx](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/)
- Find the location of your game by clicking on the gear and selecting Manage then browse local files
- Extract the contents of the zip file into the `BepInEx/plugins` folder
Or let thunderstore handle it for you.

## Usage
Simply open the chat (by clicking /) then type '.organize' and press enter.